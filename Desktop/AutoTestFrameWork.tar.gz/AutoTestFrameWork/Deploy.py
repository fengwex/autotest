#!/usr/bin/env python
# encoding: utf-8
import os,re
from fabric.api import *
global_paths={}
'''
get global variable from the config file
'''
def get_global(config):
    file=open(config,'rb+')
    lines=file.readlines()
    for line in lines:
        if '=' in line:
            g_key='$'+line.split('=')[0]
            g_value=line.split('=')[1]
            global_paths.__setitem__(g_key,g_value)
    file.close()

def get_config_envs(config):
    file = open(config, 'rb+')
    lines = file.readlines()
    local('rm -rf config/myenvs')
    envsfile=open('config/myenvs','w+');
    for line in lines:
        if line.strip()!='':
          env_info=line.split()
          if env_info[0]=='export':
             envsfile.write(line)
    file.close()
    envsfile.close()
def upload_envs():
    run('rm -rf /etc/myenvs')
    put('config/myenvs', '/etc/')
def write_envs():
    run('sed -i "s/source \/etc\/myenvs//g" /etc/profile')
    run('sed -i "/^$/d" /etc/profile' )
    run('echo "source /etc/myenvs">>/etc/profile')
'''
execute command load config file
'''
def execute(config):
    get_global(config)
    get_config_envs(config)
    upload_envs()
    write_envs()
    file=open(config,'rb+')
    lines=file.readlines()
    for line in lines:
        line=replace_global(line)
        if '@' in line:
            exec_command(line)
        if line[:3]=='put':
            exec_put(line)
        if line[:3]=='get':
            exec_pull(line)
    file.close()

'''
replace global variable to command string
'''
def replace_global(command_str):
    if global_paths.__sizeof__()>0:
        for key in global_paths:
            if key in command_str:
                replace_str=global_paths.get(key).strip('\n')
                command_str=command_str.replace(key,replace_str)
                if '//' in command_str:
                    command_str=command_str.replace('//','/')
    return command_str

'''
execute put file to remote
'''
def exec_put(command_str):
    put_info = command_str.split()
    local_file = put_info[1].strip()
    remote_dir = put_info[2].strip()
    print 'put local file: ' + local_file + ',remote dir is: ' + remote_dir
    put(local_file, remote_dir)

def put_file(local,remote):
    if remote.strip()!='' and local.strip()!='':
       put(local, remote)
'''
get file from remote
'''
def exec_pull(command_str):
    get_info = command_str.split()
    resource=get_info[1].strip()
    destination=get_info[2].strip()
    print 'get remote file: ' + resource + ' to: ' + destination
    get(resource,destination)

def get_file(remote,local):
    if remote.strip()!='' and local.strip()!='':
        get(remote,local)
'''
execute command string
'''
def exec_command(command_str):
    command_info = command_str.split('@')
    tag = command_info[0]
    command = command_info[1]
    if tag == 'local':
       local(command)
    if tag == 'remote':
       if '@kill' in command_str:
          kill_server(command_str)
       elif '@wait' in command_str:
          wait(command_str)
       else:
          run(command)
def command(cmdline):
    run(cmdline)
'''
kill server
'''
def kill_server(command_str):
    command_str=command_str.strip('\n')
    if '@kill' in command_str:
       kill_info=command_str.split('@kill')
       for s in kill_info:
           if s!='remote':
              #run('kill -9 `ps -elf | grep ' +s+' | grep -v grep | awk \'{print $4}\'`')
              return_code=run('ps -elf | grep ' +s+' | grep -v grep | awk \'{print $4}\'')
              if return_code.strip()!='':
                 run('kill -9 '+return_code)
def wait(command_str):
    command_str=command_str.strip('\n')
    if '@wait' in command_str:
       wait_info=command_str.split('remote@')[1].split()
       wait_process=wait_info[1]
       wait_timeout=wait_info[2]
       wait_timeout=int(wait_timeout)
       i=0
       while(i<=wait_timeout):
          return_code=run('ps -elf | grep ' +wait_process+' | grep -v grep | awk \'{print $4}\'')
          if (return_code.strip()==''):
            break
          else:
            local('sleep 5')  
          i=i+5
def stop_process(pname):
    return_code=run('ps -elf | grep ' +pname+' | grep -v grep | awk \'{print $4}\'')
    if (return_code.strip()!=''):
       run('kill -9 '+return_code)
def monitor_process(pname):
    return_code=run('ps -elf | grep ' +pname+' | grep -v grep | awk \'{print $4}\'')
    while(return_code.strip()!=''):
       return_code=run('ps -elf | grep ' +pname+' | grep -v grep | awk \'{print $4}\'')
       if (return_code.strip()!=''):
          local('sleep 5')
          local('echo waitting....')
       else:
          return_code=''
