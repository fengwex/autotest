#!/usr/bin/env python
# encoding: utf-8
import os,re,sys,time
from fabric.api import *
args={}
args_list=['-janus','-jpass','-tsung','-tpass','-osp','-opass','-osproxy','-ospass','-payload','-type','-threads','--help']
def usage():
   print 'Auto test for perf script'
   print 'Usage:'
   print '-janus                    Assign janus host(ip or domain)'
   print '-jpass                    Assign janus password'
   print '-tsung                    Assign tsung host(ip or domain)'
   print '-tpass                    Assign tsung password'
   print '-osp                      Assign osp server host'
   print '-opass                    Assign osp server password'
   print '-osproxy                  Assign osp proxy host'
   print '-ospass                   Assign osp proxy password'
   print '-payload                  Assign payload size'
   print '-type                     Assign test type'
   print '-threads                  Assign thread number'
   print '--help                    -h,-help,--help'
###check arguments#####
def check_arg():
 if len(sys.argv)<=1:
    usage()
    exit()
 if sys.argv[1] == '--help' or sys.argv[1] == '-h' or sys.argv[1] == '-help':
    usage()
    exit()
 for i in range(1, len(sys.argv)):
    arg=sys.argv[i]
    if '=' in arg:
       arg_array=arg.split('=')
       arg_key=arg_array[0]
       arg_value=arg_array[1]
       if arg_key not in args_list:
         print '>>>>>>>>>>>>>>>>argument error!' + '\n'
         usage()
         exit()
       else:
         args.__setitem__(arg_key,arg_value)

def print_arg_info():
    for ak in args:
        print ak+'='+args.get(ak)
check_arg()
print_arg_info()

### because dstat genarate unified data unit,k,B,M,G
def parser_dstat(logfile,newlogfile):
    local('sed -i "1,5d"'+' '+logfile)
    formatData=open(newlogfile,'w+')
    for lines in open(logfile, 'r').readlines():
        dataInfo = lines.split('|')
        time_info = dataInfo[0]
        cpu_info = dataInfo[1].split()
        mem_info = dataInfo[2].split()
        net_info = dataInfo[3].split()
        disk_info = dataInfo[4].split()
        cpu_used = str(100 - int(cpu_info[2]))
        mem_used = str(round((189 - float(mem_info[3].split('G')[0])) * 100 / 189,2))
        '''
        get net infomation
        '''
        net_recv = ''
        if net_info[0][-1:] == 'B':
            net_recv = '0'
        elif net_info[0][-1:] == 'k':
            net_recv = net_info[0].strip('k')
            net_recv = str(float(net_recv) / 1000) + 'M'
        else:
            net_recv = net_info[0]
        net_send = ''
        if net_info[1][-1:] == 'B':
            net_send = '0'
        elif net_info[1][-1:] == 'k':
            net_send = net_info[1].strip('k')
            net_send = str(float(net_send) / 1000) + 'M'
        else:
            net_send = net_info[1]
        '''
        get disk infomation
        '''
        disk_read = ''
        if disk_info[0][-1:] == 'B':
            disk_read = '0'
        elif disk_info[0][-1:] == 'k':
            disk_read = disk_info[0].strip('k')
            disk_read = str(float(disk_read) / 1000) + 'M'
        else:
            disk_read = disk_info[0]
        disk_write = ''
        if disk_info[1][-1:] == 'B':
            disk_write = '0'
        elif disk_info[1][-1:] == 'k':
            disk_write = disk_info[1].strip('k')
            disk_write = str(float(disk_write) / 1000) + 'M'
        else:
            disk_write = disk_info[1]
        new_line = time_info + " " + cpu_used + " " + mem_used \
                   + " " + net_recv + " " + net_send \
                   + " " + disk_read + " " + disk_write
        formatData.write(new_line + '\n')
####get args info###########
janus_host=args.get('-janus')
janus_pass=args.get('-jpass')
tsung_host=args.get('-tsung')
tsung_pass=args.get('-tpass')
osp_host=args.get('-osp')
osp_pass=args.get('-opass')
osproxy_host=args.get('-osproxy')
osproxy_pass=args.get('-ospass')
payload=args.get('-payload')
test_type=args.get('-type')
threads=args.get('-threads')
year=time.strftime("%Y", time.localtime())
cur_time=time.strftime("%Y%m%d%H%M", time.localtime())
####run command at remote######
def cmd_remote(cmdline,host,passwd):
    cmdline='"'+cmdline+'"'
    local('fab -f Deploy.py command:cmdline='+cmdline+' --hosts='+host+' --password='+passwd)
###get remote log method#####
def get_remote_log(remote_file,local_file,host,passwd):
    local('fab -f Deploy.py get_file:remote='+remote_file+',local='+local_file+' --hosts='+host+' --password='+passwd)
####get janus log######    
def get_janus_log(remote,local):
    suffix=test_type+'-'+payload+'-'+threads+'.log'
    cmd_remote('cd '+remote+';./paser_janus_log.sh access.log > janus-'+suffix,janus_host,janus_pass)
    ####get janus access log#######
    get_remote_log(remote+'/janus-'+suffix,local+'/janus-'+suffix,janus_host,janus_pass)
    ###get dstat data#########
    get_remote_log('/root/dstat.log','log/dstat-'+suffix,janus_host,janus_pass)
    ###get gc data#########
    get_remote_log('/root/gc.log','log/gc-'+suffix,janus_host,janus_pass)
    ###parser dstat data######
    parser_dstat('log/dstat-'+suffix,'log/format-'+suffix)
####get ospproxy log########
def get_ospproxy_log(remote,local):
    suffix=test_type+'-'+payload+'-'+threads+'.log'
    cmd_remote('cd '+remote+';./paser_ospproxy_log.sh osp-proxy_access.log > osp-proxy-'+suffix,osproxy_host,osproxy_pass)
    get_remote_log(remote+'/osp-proxy-'+suffix,local+'/osp-proxy-'+suffix,osproxy_host,osproxy_pass)
####get ospserver log###########
def get_ospserver_log(remote,local):
    suffix=test_type+'-'+payload+'-'+threads+'.log'
    cmd_remote('cd '+remote+';./paser_ospserver_log.sh osp_access.log > osp-server-'+suffix,osp_host,osp_pass)
    get_remote_log(remote+'/osp-server-'+suffix,local+'/osp-server-'+suffix,osp_host,osp_pass)
####get tsung log##########
def get_tsung_log(remote_dir,local_dir):
    #local('mkdir -p '+local_dir+'/'+cur_time)
    #get_remote_log(remote_dir+'/'+year+'*',local_dir+'/'+cur_time,tsung_host,tsung_pass)
    local('cd tsung_log;ls | grep -v pasertsung.sh | grep -v grep | xargs rm -rf')
    get_remote_log(remote_dir+'/log/'+year+'*',local_dir,tsung_host,tsung_pass)
####parser log to picture#######
def parser_log():
    #####genarate picture with the monitor data######
    local('cd plot;'+'./prepare_chart.py -file=dstatChart.sh -payload='+payload+' -type='+test_type+' -threads='+threads)
    local('cd plot;./dstatChart.sh')
    local('cd plot;'+'./prepare_chart.py -file=gcChart.sh -payload='+payload+' -type='+test_type+' -threads='+threads)
    local('cd plot;./gcChart.sh')
    #####parse tsung log####
    users=int(threads.strip())*50/100
    users=str(users)
    local('cd tsung_log;./pasertsung.sh '+users+' tsung-'+payload)
####move log to testcase dir########
def move_log():
    dir='test_result/'+test_type+'_'+payload+'_'+threads
    local('rm -rf '+dir)
    local('mkdir -p '+dir)
    local('mv log/* '+dir)
    local('mv chart/* '+dir)
    local('mv tsung_log/*.log '+dir)
####write tsung log data to html###########
def write_tsung_log():
    dir='test_result/'+test_type+'_'+payload+'_'+threads
    tsung=open(dir+'/response.log','rb+')
    tsung_lines=tsung.readlines()
    for index,line in enumerate(tsung_lines):
        if 'sec' in line and index==7:
            data=line.split('/')[0].split('>')[1].strip()
            local('sed -i "s/maxtps/'+data+'/g" '+dir+'/index.html')
        if 'sec' in line and index==8:
            data=line.split('/')[0].split('>')[1].strip()
            local('sed -i "s/meantps/'+data+'/g" '+dir+'/index.html')
    tsung.close()
#####add link picture to html##########
def write_png():
    filename='test_result/'+test_type+'_'+payload+'_'+threads+'/index.html'
    beforeSuffix='-@-'+test_type+'-@-'+payload+'-@-'+threads+'.png'
    afterSuffix='-'+test_type+'-'+payload+'-'+threads+'.png'
    local('sed -i "s/cpu'+beforeSuffix+'/cpu'+afterSuffix+'/g" '+filename)
    local('sed -i "s/memory'+beforeSuffix+'/memory'+afterSuffix+'/g" '+filename)
    local('sed -i "s/net'+beforeSuffix+'/net'+afterSuffix+'/g" '+filename)
    local('sed -i "s/disk'+beforeSuffix+'/disk'+afterSuffix+'/g" '+filename)
    local('sed -i "s/gc'+beforeSuffix+'/gc'+afterSuffix+'/g" '+filename)
####write server info log method#####
def write_server_log(slog):
    dir='test_result/'+test_type+'_'+payload+'_'+threads+'/'
    suffix=test_type+'-'+payload+'-'+threads+'.log'
    server=open(dir+slog+'-'+suffix,'rb+')
    server_lines=server.readlines()
    for line in server_lines:
        if ':' in line:
          content=line.split(':')
          key=content[0].strip()
          value=content[1].strip()
          local('sed -i "s/'+slog+'-'+key+'/'+value+'/g" '+dir+'index.html')
    server.close()
###write html to file of test result data#####
def data2Html(rfile,dfile):
    isWrite='false'
    writeHtml=open(dfile,'a+')
    ###add table title#####
    writeHtml.write('<tr>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('<br>\n')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('payload')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('threads')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('99%')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('99.9%')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('99.99%')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('99.999%')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('<span>min</span><br>\n')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('<span>max</span><br>\n')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('<span>avg</span><br>\n')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('total')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('MeanTPS')
    writeHtml.write('</td>\n')
    writeHtml.write('<td style="text-align:center;">\n')
    writeHtml.write('MaxTPS')
    writeHtml.write('</td>\n')
    writeHtml.write('</tr>\n')
    ####add table title end####
    readHtml=open(rfile,'r')
    rLines=readHtml.readlines()
    for rline in rLines:
        if 'content_start' in rline:
           isWrite='true'
        if 'content_end' in rline:
           isWrite='false'
        if isWrite=='true':
           writeHtml.write(rline)
    writeHtml.write('<tr>\n')
    writeHtml.write('<td colspan="100">\n')
    readHtml.close()
    writeHtml.close()
####write picture to file of gnuplot test data####
def data2Script(rfile,dfile):
    isWrite='false'
    writeScript=open(dfile,'a+')
    readScript=open(rfile,'r')
    rLines=readScript.readlines()
    for rline in rLines:
        if 'script_start' in rline:
           isWrite='true'
        if 'script_end' in rline:
           isWrite='false'
        if isWrite=='true':
           writeScript.write(rline)
    writeScript.write('</td>\n')
    writeScript.write('</tr>\n')
    readScript.close()
    writeScript.close()
####get test log file######
get_janus_log('/apps/logs/janus','log')
get_tsung_log('/root/.tsung','tsung_log')
get_ospproxy_log('/home/liang01.ma/testspace/osp-proxy-2.5.11/logs','log')
get_ospserver_log('/home/liang01.ma/testspace/ospserver/logs','log')
parser_log()
move_log()
####write log info data to testcase directory####
title_dir='test_result/'+test_type+'_'+payload+'_'+threads+'/index.html'
local('cp -rf model/index.html '+title_dir)
local('sed -i "s/@-type/'+test_type+'/g" '+title_dir)
local('sed -i "s/@-payload/'+payload+'/g" '+title_dir)
local('sed -i "s/@-threads/'+threads+'/g" '+title_dir)
write_server_log('janus')
write_server_log('osp-proxy')
write_server_log('osp-server')
write_tsung_log()
write_png()
####get total info to data file##########
data2Html('test_result/'+test_type+'_'+payload+'_'+threads+'/index.html','test_result/'+test_type+'_'+payload+'.data')
data2Script('test_result/'+test_type+'_'+payload+'_'+threads+'/index.html','test_result/'+test_type+'_'+payload+'.data')
