#!/usr/bin/env python
# encoding: utf-8
import os,re,sys
from fabric.api import *
file='tsung-osp-model.xml'
master='server85'
slave='kafka74'
janus='192.168.200.72'
jport='80'
jpass='vipshop!'
osproxy='192.168.200.72'
ospass='vipshop!'
osp='192.168.200.157'
opass='vipshop!'
tsung='192.168.200.74'
tpass='vipshop!'

def execute(user,threads,payload,type,count,gzip):
    local('./prepare_tsung_xml.py -file='+file+' -master='+master+' -slave='+slave+' -janus='+janus+' -jport='+jport+' -user=500 -threads=500 -number=2000 -payload=9 -gzip=true')
    local('./runTest.py  -type='+type+' -janus='+janus+' -jpass='+jpass+' -osproxy='+osproxy+' -ospass='+ospass+' -osp='+osp+' -opass='+opass+' -tsung='+tsung+' -tpass='+tpass+' -preheat=true')
    local('./prepare_tsung_xml.py -file='+file+' -master='+master+' -slave='+slave+' -janus='+janus+' -jport='+jport+' -user='+user+' -threads='+threads+' -number='+count+' -payload='+payload+' -gzip='+gzip)
    local('./runTest.py  -type='+type+' -janus='+janus+' -jpass='+jpass+' -osproxy='+osproxy+' -ospass='+ospass+' -osp='+osp+' -opass='+opass+' -tsung='+tsung+' -tpass='+tpass+' -runtest=true')
    if payload=='9':
       payload='1k'
    if payload=='49':
       payload='5k'
    if payload=='249':
       payload='25k'
    if payload=='999':
       payload='100k'
    print '>>>>>>>>>>>>>>'+payload
    local('./parserLog.py -type='+type+' -threads='+threads+' -payload='+payload+' -janus='+janus+' -jpass='+jpass+' -osproxy='+osproxy+' -ospass='+ospass+' -osp='+osp+' -opass='+opass+' -tsung='+tsung+' -tpass='+tpass)

execute('500','500','9','osp','10000','true')
execute('1000','1000','9','osp','10000','true')

#execute('500','500','49','osp','10000','true')
#execute('1000','1000','49','osp','10000','true')

#execute('500','500','249','osp','10000','true')
#execute('1000','1000','249','osp','10000','true')

#execute('500','500','999','osp','10000','true')
#execute('1000','1000','999','osp','10000','true')
#execute('2000','2000','9','osp','2500','true')
#execute('5000','5000','9','osp','1000','true')
#execute('10000','10000','9','osp','500','true')
#execute('20000','20000','9','osp','250','true')
#execute('50000','50000','9','osp','100','true')
