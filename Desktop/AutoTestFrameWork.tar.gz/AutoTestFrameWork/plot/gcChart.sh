#!/usr/bin/gnuplot
#####genarate gc infomation####
set terminal png
set output "/root/AutoTestFrameWork/chart/gc-osp-100k-500.png"
set title "gc"
set xlabel "time"
set ylabel "count"
set yrange[0:10000]
#set timefmt "%d-%m %H:%M:%S"
#set format x "%H:%M"
set grid
#set style fill solid 0.4 noborder
plot "/root/AutoTestFrameWork/log/gc-osp-100k-500.log" using 17:16 title "YGC" with lines linewidth 2,\
"/root/AutoTestFrameWork/log/gc-osp-100k-500.log" using 19:18 title "FGC" with lines linewidth 2

