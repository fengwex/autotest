#!/usr/bin/env python
# encoding: utf-8
import os,re,sys
from fabric.api import *
args={}
args_list=['-file','-payload','-threads','-type','--help']
def usage():
   print '-file             assign mode file'
   print '-payload          assign payload'
   print '-threads          assign thread number'
   print '-type             assign test type'
   print '--help            -h,-help,--help'
###check arguments#####
def check_arg():
 if len(sys.argv)==1:
    usage()
    exit()
 if sys.argv[1] == '--help' or sys.argv[1] == '-h' or sys.argv[1] == '-help':
    usage()
    exit()
 for i in range(1, len(sys.argv)):
    arg=sys.argv[i]
    if '=' in arg:
       arg_array=arg.split('=')
       arg_key=arg_array[0]
       arg_value=arg_array[1]
       if arg_key not in args_list:
         print '>>>>>>>>>>>>>>>>argument error!' + '\n'
         usage()
         exit()
       else:
         args.__setitem__(arg_key,arg_value)

def print_arg_info():
    for ak in args:
        print ak+'='+args.get(ak)
def gen_chart_script():
    local('cp -rf ../model/'+args.get('-file')+' .')
    for key in args:
        old_content='@'+key
        new_content=args.get(key)
        #replace_string="[" + '"sed",' + " \"-i \'s/"+old_content+"/"+new_content+"/g' \"," + "\""+args.get('-file') +"\"]"
        replace_cmd='sed -i "s/'+old_content+'/'+new_content+'/g" '+args.get('-file')
        print "replace command is: " + replace_cmd
        local(replace_cmd)
check_arg()
print_arg_info()
gen_chart_script()

