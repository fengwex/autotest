#!/usr/bin/gnuplot
####genarate cpu usage rate#####
set terminal png
set output "/root/AutoTestFrameWork/chart/cpu-osp-100k-500.png"
set title "cpu usage"
set xlabel "time"
set ylabel "percent"
set yrange[0:100]
set xdata time
set timefmt "%d-%m %H:%M:%S"
set format x "%H:%M"
set grid
#set style fill solid 0.4 noborder
plot "/root/AutoTestFrameWork/log/format-osp-100k-500.log" using 1:3 title "idle" with lines linewidth 2
#####genarate memory usage rate####
set output "/root/AutoTestFrameWork/chart/memory-osp-100k-500.png"
set title "memory usage"
set xlabel "time"
set ylabel "percent"
set yrange[0:100]
set xdata time
set timefmt "%d-%m %H:%M:%S"
set format x "%H:%M"
set grid
#set style fill solid 0.4 noborder
plot "/root/AutoTestFrameWork/log/format-osp-100k-500.log" using 1:4 title "memory used rate(%)" with lines linewidth 2
#####genarate net infomation rate####
set output "/root/AutoTestFrameWork/chart/net-osp-100k-500.png"
set title "network usage"
set xlabel "time"
set ylabel "size(M)"
set yrange[0:1000]
set xdata time
set timefmt "%d-%m %H:%M:%S"
set format x "%H:%M"
set grid
#set style fill solid 0.4 noborder
plot "/root/AutoTestFrameWork/log/format-osp-100k-500.log" using 1:5 title "recv" with lines linewidth 2,\
"/root/AutoTestFrameWork/log/format-osp-100k-500.log" using 1:6 title "send" with lines linewidth 2
#####genarate disk infomation rate####
set output "/root/AutoTestFrameWork/chart/disk-osp-100k-500.png"
set title "disk usage"
set xlabel "time"
set ylabel "size(M)"
set yrange[0:1000]
set xdata time
set timefmt "%d-%m %H:%M:%S"
set format x "%H:%M"
set grid
#set style fill solid 0.4 noborder
plot "/root/AutoTestFrameWork/log/format-osp-100k-500.log" using 1:7 title "read" with lines linewidth 2,\
"/root/AutoTestFrameWork/log/format-osp-100k-500.log" using 1:8 title "write" with lines linewidth 2

