#!/bin/bash
home_path=$(cd "$(dirname "$0")"; pwd)
cd $home_path
year=`date +%Y`
if [ ! -d $year* ] ; then
  echo "no tsung log"
  exit 0
fi
echo "##################################"
echo "####### Paser tsung report #######"
echo "##################################"

# enter into report path
cd $year*
users=$1
filename=$2
mv tsung.log tsung.log.bak
tac tsung.log.bak |awk -vUSERS=$users '{if(export==1){print $0}} $2=="users"{if($3>USERS){export=1}} ' | tac > tsung.log

# generator report
/usr/bin/perl /usr/local/tsung/lib/tsung/bin/tsung_stats.pl
echo "+++++++++++++++++++++++++++++++++"
# output the result
cat ./report.html | grep -A 5 '<td class="stats">request</td>' > ../requst.log
echo "+++++++++++++++++++++++++++++++++"
cat ./report.html | grep -A 10 'HTTP return code'  > ../response.log
echo "=================================================="
#cd ..
#dir=`ls | grep $year`
#tar cvf $filename".tar.gz" $dir *.log
#mv *.tar.gz ../test_result
#rm -rf *.log *.tar.gz $year*


