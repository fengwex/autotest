#!/usr/bin/env python
# encoding: utf-8
import os,re,sys,time
from fabric.api import *
args={}
args_list=['-payload','-type','-isnew','--help']
def usage():
   print 'Auto test for perf script'
   print 'Usage:'
   print '-payload                  Assign payload size'
   print '-type                     Assign test type'
   print '-isnew                    Create new dir'
   print '--help                    -h,-help,--help'
###check arguments#####
def check_arg():
 if len(sys.argv)<=1:
    usage()
    exit()
 if sys.argv[1] == '--help' or sys.argv[1] == '-h' or sys.argv[1] == '-help':
    usage()
    exit()
 for i in range(1, len(sys.argv)):
    arg=sys.argv[i]
    if '=' in arg:
       arg_array=arg.split('=')
       arg_key=arg_array[0]
       arg_value=arg_array[1]
       if arg_key not in args_list:
         print '>>>>>>>>>>>>>>>>argument error!' + '\n'
         usage()
         exit()
       else:
         args.__setitem__(arg_key,arg_value)

def print_arg_info():
    for ak in args:
        print ak+'='+args.get(ak)
check_arg()
print_arg_info()

payload=args.get('-payload')
test_type=args.get('-type')
isnew=args.get('-isnew')

if isnew=='true':
   local('rm -rf test_result/'+test_type+'_all;mkdir -p test_result/'+test_type+'_all')
   local('cp -rf `find test_result -name "*.png"` test_result/'+test_type+'_all')
   local('cp -rf model/perf/*.png test_result/'+test_type+'_all/')
   local('rm -rf test_result/data;mkdir -p test_result/data')
   local('mv test_result/*.data test_result/data')
local('cp -rf model/perf/head.html test_result/osp_all/'+payload+'.html')
headHtml=open('test_result/'+test_type+'_all/'+payload+'.html','a+')
fileContent=open('test_result/data/'+test_type+'_'+payload+'.data','r')
contentLines=fileContent.readlines()
for line in contentLines:
    headHtml.write(line)
fileContent.close()
headHtml.write('</tbody>')
headHtml.write('</table>')
headHtml.write('</body>')
headHtml.write('</html>')
headHtml.close()
