#!/usr/bin/env python
# encoding: utf-8
import os,re,sys
from fabric.api import *
args={}
args_list=['-janus','-jpass','-tsung','-tpass','-osp','-opass','-osproxy','-ospass','-type','-preheat','-runtest','--help']
def usage():
   print 'Auto test for perf script'
   print 'Usage:'
   print '-janus                    Assign janus host(ip or domain)'
   print '-jpass                    Assign janus password'
   print '-tsung                    Assign tsung host(ip or domain)'
   print '-tpass                    Assign tsung password'
   print '-osp                      Assign osp server host'
   print '-opass                    Assign osp server password'
   print '-osproxy                  Assign osp proxy host'
   print '-ospass                   Assign osp proxy password'
   print '-preheat                  if is preheat,set true'
   print '-runtest                  if is runtest,set true'
   print '-type                     Assign test type'
   print '--help                    -h,-help,--help'
###check arguments#####
def check_arg():
 if len(sys.argv)<=1:
    usage()
    exit()
 if sys.argv[1] == '--help' or sys.argv[1] == '-h' or sys.argv[1] == '-help':
    usage()
    exit()
 for i in range(1, len(sys.argv)):
    arg=sys.argv[i]
    if '=' in arg:
       arg_array=arg.split('=')
       arg_key=arg_array[0]
       arg_value=arg_array[1]
       if arg_key not in args_list:
         print '>>>>>>>>>>>>>>>>argument error!' + '\n'
         usage()
         exit()
       else:
         args.__setitem__(arg_key,arg_value)

def print_arg_info():
    for ak in args:
        print ak+'='+args.get(ak)
check_arg()
print_arg_info()

janus_host=args.get('-janus')
#print '>>>>>>>>janus_host::'+janus_host
janus_pass=args.get('-jpass')
#print '>>>>>>>>janus_pass::'+janus_pass
tsung_host=args.get('-tsung')
#print '>>>>>>>>tsung_host::'+tsung_host
tsung_pass=args.get('-tpass')
#print '>>>>>>>>tsung_pass::'+tsung_pass
osp_host=args.get('-osp')
#print '>>>>>>>>osp_host::'+osp_host
osp_pass=args.get('-opass')
#print '>>>>>>>>osp_pass::'+osp_pass
osproxy_host=args.get('-osproxy')
#print '>>>>>>>>osproxy_host::'+osproxy_host
osproxy_pass=args.get('-ospass')
#print '>>>>>>>>osproxy_pass::'+osproxy_pass
test_type=args.get('-type')
#print '>>>>>>>>test_type::'+test_type
preheat=args.get('-preheat')
runtest=args.get('-runtest')

def execute(config,host,passwd):
    print 'config>>>>>>>'+config
    print 'host>>>>>>>>>'+host
    print 'passwd>>>>>>>'+passwd
    if host==None or passwd==None:
       print 'please assign host and pass!'
       return 1
    if host.strip()!='' and passwd.strip()!='':
       local('fab -f Deploy.py execute:config='+config+' --hosts='+host+ ' --password='+passwd)
    else:
       print 'please input right arguments'

def clean_server_log(dir,script,host,passwd):
    cmdline='cd '+dir+';'+'chmod +x '+script+';./'+script
    cmdline=cmdline='"'+cmdline+'"'
    local('fab -f Deploy.py command:cmdline='+cmdline+' --hosts='+host+' --password='+passwd)


#local('./prepare_tsung_xml.py -file=tsung-osp-model.xml -master=server85 -slave=kafka74 -janus=192.168.200.72 -jport=80 -user=500 -threads=500 -number=2000 -payload=9 -gzip=true')

if preheat=='true':
   ###define the test type###
   local('cp -rf model/tsung_model'+' config/tsung')
   local('sed -i "s/@type/'+test_type+'/g" config/tsung')
   ###start janus###
   execute('config/janus_start',janus_host,janus_pass)
   ###start osp proxy###
   execute('config/osp_proxy',osproxy_host,osproxy_pass)
   ###start osp####
   execute('config/osp_server',osp_host,osp_pass)
   ###start tsung###
   execute('config/tsung',tsung_host,tsung_pass)

#local('./prepare_tsung_xml.py -file=tsung-osp-model.xml -master=server85 -slave=kafka74 -janus=192.168.200.72 -jport=80 -user=500 -threads=500 -number=10000 -payload=9 -gzip=true')

if runtest=='true':
   clean_server_log('/home/liang01.ma/testspace/osp-proxy-2.5.11/logs','clean_ospproxy_log.sh',osproxy_host,osproxy_pass)
   clean_server_log('/home/liang01.ma/testspace/ospserver/logs','clean_ospserver_log.sh',osp_host,osp_pass)
   ###run test on janus server#######
   execute('config/janus_test',janus_host,janus_pass)
   ###run test on tsung server########
   execute('config/tsung',tsung_host,tsung_pass)
   execute('config/stop',janus_host,janus_pass)

#local('./parserLog.py -type=osp -payload=1k -janus=192.168.200.72 -jpass=vipshop! -osproxy=192.168.200.72 -ospass=vipshop! -osp=192.168.200.157 -opass=vipshop! -tsung=192.168.200.74 -tpass=vipshop!')
