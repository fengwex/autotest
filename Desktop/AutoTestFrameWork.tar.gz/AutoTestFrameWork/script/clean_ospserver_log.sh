> gc-osp.log
> osp_access.log
> osp_error.log
> osp_flow.log
> osp-osp.out
rm -rf *2016*
rm -rf tmp*
