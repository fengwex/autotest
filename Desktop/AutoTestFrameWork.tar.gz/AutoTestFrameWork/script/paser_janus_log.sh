echo "##################################"
echo "#### API Gateway Access Log  #####"
echo "##################################"
sed '1,1000000d' $1 | awk -F ' ' '{print $(NF-6)}' > tmp.log
if [ -f  access-1.log ]; then 
	awk -F ' ' '{print $7}' access-1.log >> tmp.log
fi

if [ -f  access-2.log ]; then 
	awk -F ' ' '{print $7}' access-2.log >> tmp.log
fi

sort -n tmp.log -o tmp2.log
echo avg : `awk '{sum+=$1} END {print sum/NR}' tmp2.log`
total=`cat tmp2.log|wc -l`
l99=$[$total-$total/100]
l999=$[$total-$total/1000]
l9999=$[$total-$total/10000]
l99999=$[$total-$total/100000]
echo total: $total
echo min: `sed -n 1p tmp2.log`
echo max: `sed -n ${total}p tmp2.log`
echo 99% : `sed -n ${l99}p tmp2.log`
echo 99.9% : `sed -n ${l999}p tmp2.log`
echo 99.99% : `sed -n ${l9999}p tmp2.log`
echo 99.999% : `sed -n ${l99999}p tmp2.log`
echo " "
