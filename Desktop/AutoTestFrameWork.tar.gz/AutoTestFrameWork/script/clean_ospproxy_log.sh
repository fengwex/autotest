echo "clean osp-proxy log"
> gc-osp-proxy.log
> osp-proxy_access.log
> osp-proxy_error.log
> osp-proxy_flow.log
> osp-proxy.out
rm -rf *2016*
rm -rf tmp*
