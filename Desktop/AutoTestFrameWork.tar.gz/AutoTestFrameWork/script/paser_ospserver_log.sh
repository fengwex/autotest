#!/bin/bash

echo "##################################"
echo "#### Osp-Service Access Log  #####"
echo "##################################"
sed /getServiceDescriptor/d $1|awk '{print $NF*1}'> tmp.log
sort -n tmp.log -o tmp2.log
echo avg : `awk '{sum+=$1} END {print sum/NR}' tmp2.log`
total=`cat tmp2.log|wc -l`
echo total: $total
l99=$[$total-$total/100]
l999=$[$total-$total/1000]
l9999=$[$total-$total/10000]
l99999=$[$total-$total/100000]
echo min: `sed -n 1p tmp2.log`
echo max: `sed -n ${total}p tmp2.log`
echo 99% : `sed -n ${l99}p tmp2.log`
echo 99.9% : `sed -n ${l999}p tmp2.log`
echo 99.99% : `sed -n ${l9999}p tmp2.log`
echo 99.999% : `sed -n ${l99999}p tmp2.log`

echo " "
