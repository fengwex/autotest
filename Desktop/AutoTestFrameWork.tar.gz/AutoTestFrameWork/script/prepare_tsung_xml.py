#!/usr/bin/env python
# encoding: utf-8
import os,re,sys
from fabric.api import *
args={}
args_list=['-file','-master','-slave','-janus','-jport','-user','-threads','-number','-payload','-gzip','--help']
def usage():
   print '-file             assgin mode file'
   print '-master           assing tsung master host'
   print '-slave            assgin tsung slave host'
   print '-janus            assign janus host'
   print '-jport             assgin janus port'
   print '-user             assgin max simulated user number'
   print '-threads          assign concurrent number'
   print '-number           assign request times for every user'
   print '-payload          assing payload (osp:9 as 1k,49 as 5k,249 as 25k,999 as 100k;http:1 as 1k,5 as 5k,25 as 25k,100 as 100k)'
   print '--is-gzip         default is not gzip,it is for gzip http request'
   print '--help            -h,-help,--help'
###check arguments#####
def check_arg():
 if len(sys.argv)<=1:
    usage()
    exit()
    return 1
 if sys.argv[1] == '--help' or sys.argv[1] == '-h' or sys.argv[1] == '-help':
    usage()
    exit()
    return 2
 #if sys.argv[1] not in args_list:
 #   print '>>>>>>>>>>>>>>>>>>>argument error!' +'\n'
 #   usage()
 #   return 0
 for i in range(1, len(sys.argv)):
    arg=sys.argv[i]
    if '=' in arg:
       arg_array=arg.split('=')
       arg_key=arg_array[0]
       arg_value=arg_array[1]
       if arg_key not in args_list:
         print '>>>>>>>>>>>>>>>>argument error! ' + 'no ' + arg_key +'\n'
         usage()
         exit()
         return 3
       else:
         args.__setitem__(arg_key,arg_value)

def print_arg_info():
    if len(args)==0:
       print 'no content should be replace'
    for ak in args:
        print ak+'='+args.get(ak)
def gen_test_xml():
    xml_file=args.get('-file')
    if xml_file==None:
       print 'please assign xml file'
       return 3
    local('cp -rf ../model/'+xml_file+' .')
    del args['-file']
    for key in args:
        old_content='@'+key
        new_content=args.get(key)
        #replace_string="[" + '"sed",' + " \"-i \'s/"+old_content+"/"+new_content+"/g' \"," + "\""+args.get('-file') +"\"]"
        replace_cmd='sed -i "s/'+old_content+'/'+new_content+'/g" '+xml_file
        print "replace command is: " + replace_cmd
        local(replace_cmd)
    if args.get('-gzip')!=None and args.get('-gzip')=='true':
        replace_cmd1='sed -i "s/<!--http_header/<http_header/g" '+xml_file
        replace_cmd2='sed -i "s/tag-->//g" '+xml_file
        local(replace_cmd1)
        local(replace_cmd2)

check_arg()
print_arg_info()
gen_test_xml()

