#!/bin/bash
for ((i=1; i<=600; i++))
do
    line=`java -jar cmdline-jmxclient-0.10.3.jar - localhost:8061 "vip.jmx:type=vGCutil" ALL`
    echo $line | grep -v warning | grep -v grep
    #java -jar cmdline-jmxclient-0.10.3.jar root:vipshop! localhost:8061 "vip.jmx:type=vGCutil" ALL >> gc.log
    sleep 1
done

